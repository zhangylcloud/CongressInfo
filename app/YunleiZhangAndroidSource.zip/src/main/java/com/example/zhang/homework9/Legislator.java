package com.example.zhang.homework9;

import java.io.Serializable;

/**
 * Created by zhang on 11/29/2016.
 */

public class Legislator implements Serializable{
    public String bioguide_id="";
    public String state="";
    public String stateName = "";
    public String chamber="";
    public String title="";
    public String lastname="";
    public String firstname="";

    public String photoUrl="";
    public String party="";
    public String district="";
    public String facebook="";
    public String twitter="";
    public String website="";
    public String email="";
    public String contact="";
    public String startTerm="";
    public String endTerm="";
    public String office="";
    public String fax="";
    public String birthday="";



    /*public Legislator(String bioguide_id, String state, String chamber, String lastname, String firstname,
                        String title, String photoUrl, String party, String district, String facebook, String twitter, String website,
                      String email, String contact, String startTerm, String endTerm, String office, String fax, String birthday){

        this.bioguide_id  = bioguide_id;
        this.state = state;
        this.chamber = chamber;
        this.lastname = lastname;
        this.
    }*/


}
