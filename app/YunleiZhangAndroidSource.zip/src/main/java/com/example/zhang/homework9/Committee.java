package com.example.zhang.homework9;

import java.io.Serializable;

/**
 * Created by zhang on 12/1/2016.
 */

public class Committee implements Serializable {
    public String committeeId = "";
    public String committeeName = "";
    public String chamber = "";
    public String parentCommitteeId = "";
    public String contact = "";
    public String office = "";
}
