package com.example.zhang.homework9;

import android.os.Bundle;
import android.app.Activity;

public class AboutMe extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);
    }

}
