package com.example.zhang.homework9;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link fav_main.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link fav_main#newInstance} factory method to
 * create an instance of this fragment.
 */
@TargetApi(11)
public class fav_main extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {
    public SharedPreferences prefs;


    private static final String LOG_TAG = MainActivity.class.getName();

    private LegislatorAdapter favLegAdapter;
    private BillAdapter favBillAdapter;
    private CommitteeAdapter favComAdapter;

    private TextView mEmptyStateTextViewFLeg;
    private TextView mEmptyStateTextViewFBill;
    private TextView mEmptyStateTextViewFCom;

    private List<Legislator> favLegList;
    private List<Bill> favBillList;
    private List<Committee> favComList;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public fav_main() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment fav_main.
     */
    // TODO: Rename and change types and number of parameters
    public static fav_main newInstance(String param1, String param2) {
        fav_main fragment = new fav_main();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        favLegList = new ArrayList<Legislator>();
        favBillList = new ArrayList<Bill>();
        favComList = new ArrayList<Committee>();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {





        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fav_main, container, false);
    }

    public void onActivityCreated (Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);



        ListView favListViewLeg = (ListView) getView().findViewById(R.id.list_fav_leg);
        mEmptyStateTextViewFLeg = (TextView) getView().findViewById(R.id.empty_view_fav_leg);
        favListViewLeg.setEmptyView(mEmptyStateTextViewFLeg);

        ListView favListViewBill = (ListView) getView().findViewById(R.id.list_fav_bill);
        mEmptyStateTextViewFBill = (TextView) getView().findViewById(R.id.empty_view_fav_bill);
        favListViewBill.setEmptyView(mEmptyStateTextViewFBill);

        ListView favListViewCom = (ListView) getView().findViewById(R.id.list_fav_com);
        mEmptyStateTextViewFCom = (TextView) getView().findViewById(R.id.empty_view_fav_com);
        favListViewCom.setEmptyView(mEmptyStateTextViewFCom);

        favLegAdapter = new LegislatorAdapter(getActivity(), new ArrayList<Legislator>());
        favBillAdapter = new BillAdapter(getActivity(), new ArrayList<Bill>());
        favComAdapter = new CommitteeAdapter(getActivity(), new ArrayList<Committee>());

        favListViewLeg.setAdapter(favLegAdapter);
        favListViewBill.setAdapter(favBillAdapter);
        favListViewCom.setAdapter(favComAdapter);




        favListViewLeg.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent("com.example.zhang.homework9.LegDetailActivity");
                intent.putExtra("myLegislator", favLegList.get(position));
                startActivity(intent);
            }
        });
        favListViewBill.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent("com.example.zhang.homework9.BillDetailActivity");
                intent.putExtra("myBill", favBillList.get(position));
                startActivity(intent);
            }
        });
        favListViewCom.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent("com.example.zhang.homework9.ComDetailActivity");
                intent.putExtra("myCommittee", favComList.get(position));
                startActivity(intent);
            }
        });

        TabHost tab = (TabHost) getView().findViewById(android.R.id.tabhost);
        tab.setup();
        TabHost.TabSpec spec1 = tab.newTabSpec("favLeg");
        spec1.setIndicator("Legislators");
        spec1.setContent(R.id.favLeg);
        tab.addTab(spec1);

        TabHost.TabSpec spec2 = tab.newTabSpec("favBill");
        spec2.setIndicator("Bills");
        spec2.setContent(R.id.favBill);
        tab.addTab(spec2);

        TabHost.TabSpec spec3 = tab.newTabSpec("favCom");
        spec3.setIndicator("Committee");
        spec3.setContent(R.id.favCom);
        tab.addTab(spec3);

    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }



    @Override
    public void onResume() {
        super.onResume();
        // Set up a listener whenever a key changes
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        //getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        //getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        // Unregister the listener whenever a key changes
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        //getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        //getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        Log.d("SharedPref", "EnterOnSharedPreferenceChange");
        if(sharedPreferences.contains("LEGISLATOR")){
            Map<String, ?> keys = sharedPreferences.getAll();
            for(Map.Entry<String, ?> entry : keys.entrySet()){
                if(!entry.getKey().equals("LEGISLATOR")){
                    favLegList.clear();
                    String curLegJson = (String)entry.getValue();
                    Gson gson = new Gson();
                    Legislator curLegislator = gson.fromJson(curLegJson, Legislator.class);
                    favLegList.add(curLegislator);
                }
            }
        }
        else if(sharedPreferences.contains("BILL")){
            Map<String, ?> keys = sharedPreferences.getAll();
            for(Map.Entry<String, ?> entry : keys.entrySet()){
                if(!entry.getKey().equals("BILL")){
                    favBillList.clear();
                    String curBillJson = (String)entry.getValue();
                    Gson gson = new Gson();
                    Bill curBill = gson.fromJson(curBillJson, Bill.class);
                    favBillList.add(curBill);
                }
            }
        }
        else if(sharedPreferences.contains("COMMITTEE")){
            Map<String, ?> keys = sharedPreferences.getAll();
            for(Map.Entry<String, ?> entry : keys.entrySet()){
                if(!entry.getKey().equals("COMMITTEE")){
                    favComList.clear();
                    String curComJson = (String)entry.getValue();
                    Gson gson = new Gson();
                    Committee curCommittee = gson.fromJson(curComJson, Committee.class);
                    favComList.add(curCommittee);
                }
            }
        }
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


}
